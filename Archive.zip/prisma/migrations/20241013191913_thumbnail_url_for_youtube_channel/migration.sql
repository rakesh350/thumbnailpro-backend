-- AlterTable
ALTER TABLE "YouTubeChannel" ADD COLUMN     "thumnailUrl" TEXT NOT NULL DEFAULT 'channel-thumbnail.png';
