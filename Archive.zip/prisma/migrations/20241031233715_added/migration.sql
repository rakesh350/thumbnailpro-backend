-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "thumbnailUrl" TEXT NOT NULL DEFAULT 'video-thumbnail.png';
